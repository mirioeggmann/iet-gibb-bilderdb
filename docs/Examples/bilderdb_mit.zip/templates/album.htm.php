<table cellpadding="0" cellspacing="0">
  <tr><td><h2>Album hinzufügen</h2></td></tr>
  <tr><td>&nbsp;</td></tr>
</table>
